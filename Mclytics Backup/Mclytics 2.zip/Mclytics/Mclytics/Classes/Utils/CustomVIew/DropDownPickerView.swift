//
//  DropDownPickerView.swift
//  TestSpatialite
//
//  Created by Gaurav on 03/08/19.
//  Copyright © 2019 Gaurav. All rights reserved.
//

import UIKit

class DropDownPickerView: UIPickerView {
    
    var pickerOptions:Array<String> = []
    var currentTextField:UITextField!
    
    
}
